self.__precacheManifest = [
  {
    "revision": "88dde088ba6f3432925b8ef6b4bf785d",
    "url": "/namaz/img/sadjda-shafii.88dde088.png"
  },
  {
    "revision": "ab10ef23e7bb194235672346905d7bd8",
    "url": "/namaz/images/namaz/mareed/salam.png"
  },
  {
    "revision": "da4cad3b5ce4b206909c",
    "url": "/namaz/js/chunk-vendors.93cea97a.js"
  },
  {
    "revision": "9fd41f891e5dc42b4f506e15b679faa7",
    "url": "/namaz/images/namaz/mareed/tashahhud.png"
  },
  {
    "revision": "15f210ce7b85823aa339",
    "url": "/namaz/js/namaz.48bb80c4.js"
  },
  {
    "revision": "7f903ae9cd67a7ca00f5206455ba4d2a",
    "url": "/namaz/images/namaz/mareed/takbir.png"
  },
  {
    "revision": "b19475736d0ce634644d",
    "url": "/namaz/js/namaz~solaatil-uulaa~wudu.689fe397.js"
  },
  {
    "revision": "886e8c8b04691136f2c7ba4a196365f1",
    "url": "/namaz/index.html"
  },
  {
    "revision": "e1a2bbbf0fabc48e7383",
    "url": "/namaz/js/namaz~tahharah~wudu.c4831249.js"
  },
  {
    "revision": "7590d43a0e91371db365bb3b6cc95208",
    "url": "/namaz/img/tayammum.7590d43a.png"
  },
  {
    "revision": "09484bc8ae8847b16756",
    "url": "/namaz/js/shart.7336bd06.js"
  },
  {
    "revision": "e04dcf9222e69859e2b2a599220caba5",
    "url": "/namaz/img/wudu-shafii.e04dcf92.png"
  },
  {
    "revision": "d14fb15881254019ded1",
    "url": "/namaz/js/solaatil-uulaa.e8763bd9.js"
  },
  {
    "revision": "d5f1b98baa9f492e9f71d390e2742b5d",
    "url": "/namaz/img/wudu.d5f1b98b.png"
  },
  {
    "revision": "b21162d2a3e9a4e41de8",
    "url": "/namaz/js/tahharah.3833ad0e.js"
  },
  {
    "revision": "ccc5239303e815d33c3547f26861041a",
    "url": "/namaz/img/masah.ccc52393.png"
  },
  {
    "revision": "819cf90e93b09498b1a5",
    "url": "/namaz/js/wudu.fcf9db18.js"
  },
  {
    "revision": "25557e57fda71d5cdde86c2893c44372",
    "url": "/namaz/img/section-bg.25557e57.png"
  },
  {
    "revision": "b8ee2284addbd82de8b65f432d8695a7",
    "url": "/namaz/img/congratulations-bg.b8ee2284.png"
  },
  {
    "revision": "944316af7e6d4a9a4d774c1ff9e67805",
    "url": "/namaz/img/fadjr.944316af.jpg"
  },
  {
    "revision": "d2846aee06673e065c31e8ce2a82a49f",
    "url": "/namaz/img/fadjr-w.d2846aee.jpg"
  },
  {
    "revision": "68bd2e9c04db7e600c162dd9d8916443",
    "url": "/namaz/img/dhuhr.68bd2e9c.jpg"
  },
  {
    "revision": "8cd323c2acf3a9ae5a026ec1d44518bd",
    "url": "/namaz/img/dhuhr-w.8cd323c2.jpg"
  },
  {
    "revision": "71b5a41cfc30f94eb576334075aa569a",
    "url": "/namaz/img/asr.71b5a41c.jpg"
  },
  {
    "revision": "cfbecbafcfdc2b0158e830de3bd77b55",
    "url": "/namaz/img/asr-w.cfbecbaf.jpg"
  },
  {
    "revision": "ebc11d11ea145ad1bef8f7941075c7e8",
    "url": "/namaz/img/maghrib.ebc11d11.jpg"
  },
  {
    "revision": "b56bcc0bb71227a60b155da3dcf59f78",
    "url": "/namaz/img/maghrib-w.b56bcc0b.jpg"
  },
  {
    "revision": "06ced615e89b6a2d561f35389b4564fe",
    "url": "/namaz/img/isha.06ced615.jpg"
  },
  {
    "revision": "5c92abd87dc5a0f3e328e2e6ea3c9594",
    "url": "/namaz/img/isha-w.5c92abd8.jpg"
  },
  {
    "revision": "2efd5c64c5b3904e243d519e7123c66d",
    "url": "/namaz/img/witr.2efd5c64.jpg"
  },
  {
    "revision": "f97f7090d0869e5d28aacd5e65a2d051",
    "url": "/namaz/img/witr-w.f97f7090.jpg"
  },
  {
    "revision": "7e6855b17fb1f39209b9b2d0b051aca3",
    "url": "/namaz/img/tarawih.7e6855b1.jpg"
  },
  {
    "revision": "cf5edadafd872a91b90dded9bd9a9011",
    "url": "/namaz/img/id.cf5edada.jpg"
  },
  {
    "revision": "163194b76e56b376c5b3a83bc87863b1",
    "url": "/namaz/img/mareed.163194b7.jpg"
  },
  {
    "revision": "7b3fb7477e2e39fa068df3bb4be87cdd",
    "url": "/namaz/img/istibra.7b3fb747.png"
  },
  {
    "revision": "b69e23d573b3c22f16eb7a4051d3d27f",
    "url": "/namaz/img/masah.b69e23d5.png"
  },
  {
    "revision": "176b80b3152358a9a08bd4955c26009b",
    "url": "/namaz/img/istinja.176b80b3.png"
  },
  {
    "revision": "94ad9ba9cdf8bdb0898a991cf8cfe447",
    "url": "/namaz/img/jumuah.94ad9ba9.png"
  },
  {
    "revision": "e451a6ef831989febdd9b8e332da3d4b",
    "url": "/namaz/img/tayammum.e451a6ef.png"
  },
  {
    "revision": "3ea7b9be1b65959c002d08bd4ba52d69",
    "url": "/namaz/img/masah-bg.3ea7b9be.png"
  },
  {
    "revision": "e207c1c24c54e9e1571b11b21e3e172c",
    "url": "/namaz/img/masah-bg-m.e207c1c2.png"
  },
  {
    "revision": "71060f4b047a2400cd50a54431f91b4e",
    "url": "/namaz/img/istibra-bg.71060f4b.png"
  },
  {
    "revision": "86a64aef4c19ff6c7d0ec4c33e45134f",
    "url": "/namaz/img/istibra-bg-m.86a64aef.png"
  },
  {
    "revision": "78020153373052f91f4c615ef7f8d2c5",
    "url": "/namaz/img/id-bg.78020153.png"
  },
  {
    "revision": "06b048a11d14d557e4f56c2330aac3cd",
    "url": "/namaz/img/istinja-bg.06b048a1.png"
  },
  {
    "revision": "c9dd5570dbe36df0ac18a65ae178b460",
    "url": "/namaz/img/wudu-bg.c9dd5570.png"
  },
  {
    "revision": "13c61ce464512830ece511ffb0b04844",
    "url": "/namaz/img/ghusl-bg.13c61ce4.png"
  },
  {
    "revision": "5de99373b049835a4b016a6993c19e0f",
    "url": "/namaz/img/maghrib-bg-w.5de99373.png"
  },
  {
    "revision": "74e05fb1fea4d3a3eabedec1e36fd3f6",
    "url": "/namaz/img/tayammum-bg.74e05fb1.png"
  },
  {
    "revision": "30f21fe6590126b70ef6cb4a52866916",
    "url": "/namaz/img/maghrib-bg.30f21fe6.png"
  },
  {
    "revision": "08734e35ac5070a6d4dbfc276c867aa2",
    "url": "/namaz/img/asr-bg-w.08734e35.png"
  },
  {
    "revision": "5e70bf8482d33e5332e4f21aeb77805b",
    "url": "/namaz/img/isha-bg-w.5e70bf84.png"
  },
  {
    "revision": "f385bebd8c8cdf6c7356f3e17fa2d71b",
    "url": "/namaz/img/mareed-bg.f385bebd.png"
  },
  {
    "revision": "397b36e6a413b80807e4e7b34e9cbac3",
    "url": "/namaz/img/fadjr-bg-w.397b36e6.png"
  },
  {
    "revision": "a45014fecc09e99d705132f5cdf896d6",
    "url": "/namaz/img/witr-bg.a45014fe.png"
  },
  {
    "revision": "65c975181adb8da2579097bdfd3b63cc",
    "url": "/namaz/img/wudu-bg-shafii.65c97518.png"
  },
  {
    "revision": "34f7221c5170b722d027492aae499782",
    "url": "/namaz/img/witr-bg-w.34f7221c.png"
  },
  {
    "revision": "cad1357d3f81c6360a77c984c3b60b97",
    "url": "/namaz/img/tarawih-bg.cad1357d.png"
  },
  {
    "revision": "c27505a9d76c7f112459066d7f69ed81",
    "url": "/namaz/img/asr-bg.c27505a9.png"
  },
  {
    "revision": "38edcbf4ff91bcc6ff55e93593dc4ad8",
    "url": "/namaz/img/dhuhr-bg-w.38edcbf4.png"
  },
  {
    "revision": "87b97ed72e9740c5bd3f3298fa83c688",
    "url": "/namaz/img/isha-bg.87b97ed7.png"
  },
  {
    "revision": "3b3d2e425d6aa7022f08e681831fa242",
    "url": "/namaz/img/ghusl-bg-m.3b3d2e42.png"
  },
  {
    "revision": "8ff732f6887afb540b5a96cb6c46430a",
    "url": "/namaz/img/fadjr-bg.8ff732f6.png"
  },
  {
    "revision": "6dad5ce2e5eae7c624d6c55d8e336256",
    "url": "/namaz/img/dhuhr-bg.6dad5ce2.png"
  },
  {
    "revision": "5469ebc48a0e46ef1e21ca81445cc4b1",
    "url": "/namaz/img/jumuah-bg.5469ebc4.png"
  },
  {
    "revision": "dcf512e06ddfc3a78cda08e940673dd7",
    "url": "/namaz/img/istinja-bg-m.dcf512e0.png"
  },
  {
    "revision": "9e483f337275b0b17fd8d2621ac8da92",
    "url": "/namaz/img/wudu-bg-m.9e483f33.png"
  },
  {
    "revision": "2940b7d4719962b35af49e6308b3268e",
    "url": "/namaz/img/dhuhr-bg-m.2940b7d4.png"
  },
  {
    "revision": "5e7b86fe1e8e62f001ddc6f6e3a723b7",
    "url": "/namaz/img/tayammum-bg-m.5e7b86fe.png"
  },
  {
    "revision": "2849117748183276c02ce972bcccabcf",
    "url": "/namaz/img/fadjr-bg.28491177.jpg"
  },
  {
    "revision": "44e80c93375881ec073a876b454a02ec",
    "url": "/namaz/img/dhuhr-bg.44e80c93.jpg"
  },
  {
    "revision": "adbf8da615195e6f7e9d992a7489822f",
    "url": "/namaz/img/asr-bg.adbf8da6.jpg"
  },
  {
    "revision": "9d30f63b8e07a1c9611d9718da926641",
    "url": "/namaz/img/maghrib-bg.9d30f63b.jpg"
  },
  {
    "revision": "ceff74c4332e05b7b2f33ec77bbf20b5",
    "url": "/namaz/img/isha-bg.ceff74c4.jpg"
  },
  {
    "revision": "67321d4c74f458a284fa670db67dd038",
    "url": "/namaz/img/witr-bg.67321d4c.jpg"
  },
  {
    "revision": "5de49986d5180d95aee78fd642a908d5",
    "url": "/namaz/img/buttons-bg.5de49986.jpg"
  },
  {
    "revision": "075f0e40a5bbdd509e78f6e20223c3f7",
    "url": "/namaz/img/footer-bg.075f0e40.png"
  },
  {
    "revision": "ee23a4311e9aa695380d53f012611921",
    "url": "/namaz/img/image-bg-m.ee23a431.jpg"
  },
  {
    "revision": "a7e3a7cc6d5096dbb61f894ca1b36494",
    "url": "/namaz/img/select-bg.a7e3a7cc.jpg"
  },
  {
    "revision": "7a830b090f83365b13885fcdd9a7e06d",
    "url": "/namaz/img/footer-bg-m.7a830b09.png"
  },
  {
    "revision": "c22781c2f0e3643cf3e6db199f2545c4",
    "url": "/namaz/img/woman-shafii.c22781c2.png"
  },
  {
    "revision": "27415876c269ba21d16a82b6e7d6aa3b",
    "url": "/namaz/img/woman.27415876.png"
  },
  {
    "revision": "afc593f0d4c2436f2a221fade46468ce",
    "url": "/namaz/img/man.afc593f0.png"
  },
  {
    "revision": "551891640ed714efe2a919dc20179773",
    "url": "/namaz/img/man-shafii.55189164.png"
  },
  {
    "revision": "700539a8d8ec66f6d98f3b92a92768af",
    "url": "/namaz/img/select-bg.700539a8.png"
  },
  {
    "revision": "49869136edd2e8546d8b0bce178be2a8",
    "url": "/namaz/img/woman-shafii-m.49869136.png"
  },
  {
    "revision": "cfa89f32081a0807c4794b9617385625",
    "url": "/namaz/img/woman-m.cfa89f32.png"
  },
  {
    "revision": "49c3d35b69f0a06414994837dd443c43",
    "url": "/namaz/img/man-m.49c3d35b.png"
  },
  {
    "revision": "e94cee5b94bdca79bad6c49869d30483",
    "url": "/namaz/img/man-shafii-m.e94cee5b.png"
  },
  {
    "revision": "653ff28969ed88ffd21a347db5bdab41",
    "url": "/namaz/img/ma-hiya.653ff289.jpg"
  },
  {
    "revision": "20df3b25dc8ae9150e898a2645e020ea",
    "url": "/namaz/img/aqsaam.20df3b25.jpg"
  },
  {
    "revision": "91c63017730a07a6a34138e3a7a05f54",
    "url": "/namaz/img/aadaab.91c63017.jpg"
  },
  {
    "revision": "27b4c73f8947c7246edf34e457d6d24a",
    "url": "/namaz/img/azan-iqamat.27b4c73f.jpg"
  },
  {
    "revision": "c1517262328d26f0b24a17ae5c6a437c",
    "url": "/namaz/img/fasaad.c1517262.jpg"
  },
  {
    "revision": "ba9e4c0eaf3578b3f01d64870a5d979f",
    "url": "/namaz/img/shuruut.ba9e4c0e.jpg"
  },
  {
    "revision": "10f5222ae488f897ea11abee8069f750",
    "url": "/namaz/img/bg.10f5222a.png"
  },
  {
    "revision": "220ed6381278445607c2f350b20fb6e5",
    "url": "/namaz/img/bg-asr.220ed638.png"
  },
  {
    "revision": "8ff1054cbacdca34d72e2a924bacaaf5",
    "url": "/namaz/img/bg-fadjr.8ff1054c.png"
  },
  {
    "revision": "ce1c3786b650426ed1d41268c59aae3b",
    "url": "/namaz/img/bg-dhuhr.ce1c3786.png"
  },
  {
    "revision": "89edb135c109c2d4f005730156312601",
    "url": "/namaz/img/bg-maghrib.89edb135.png"
  },
  {
    "revision": "881d9fbb6ae8854fe947837f563c109f",
    "url": "/namaz/img/bg-isha.881d9fbb.png"
  },
  {
    "revision": "773f31cab0957771267bf012b0dd04df",
    "url": "/namaz/img/bg-witr.773f31ca.png"
  },
  {
    "revision": "e927158f7a6da75e0dc6aed09e4a53b8",
    "url": "/namaz/img/bg.e927158f.png"
  },
  {
    "revision": "94a042b82b418d86d5eb4cfa2453730b",
    "url": "/namaz/img/full-bg.94a042b8.png"
  },
  {
    "revision": "6962ac7458bc247a2bad3175d367817b",
    "url": "/namaz/img/namaz-bg.6962ac74.jpg"
  },
  {
    "revision": "5dcca553fc4174905664944fdf6789ae",
    "url": "/namaz/img/bg-small.5dcca553.png"
  },
  {
    "revision": "8e2171964f280fe4184d2406623c3bf7",
    "url": "/namaz/img/bg-small-witr.8e217196.png"
  },
  {
    "revision": "301d9ff1a28567425502bce03ab1f789",
    "url": "/namaz/img/bg-small-asr.301d9ff1.png"
  },
  {
    "revision": "cd25dcfbf6c74eebc432edc12b1860b6",
    "url": "/namaz/img/bg.cd25dcfb.png"
  },
  {
    "revision": "6b728a4180e5a00ba2c614886e23af47",
    "url": "/namaz/img/bg-fadjr.6b728a41.jpg"
  },
  {
    "revision": "33490bd9aeb22ac326d68557f77ae465",
    "url": "/namaz/img/bg-maghrib.33490bd9.jpg"
  },
  {
    "revision": "10279c47a930c9e51a3f950231e58c9f",
    "url": "/namaz/img/bg-dhuhr.10279c47.jpg"
  },
  {
    "revision": "292d262be1429a4b28da23958bc872e0",
    "url": "/namaz/img/bg-id.292d262b.jpg"
  },
  {
    "revision": "b4625a0dd2f120bed1f4e40d3daaa2a4",
    "url": "/namaz/img/bg-asr.b4625a0d.jpg"
  },
  {
    "revision": "192040453a59ed6f1c879047230a337f",
    "url": "/namaz/img/bg-witr.19204045.jpg"
  },
  {
    "revision": "2d74c963bba51d2c2496d673790c692a",
    "url": "/namaz/img/bg-jumuah.2d74c963.jpg"
  },
  {
    "revision": "9f4f237567c137c1ba3c4424692acb49",
    "url": "/namaz/img/bg-isha.9f4f2375.jpg"
  },
  {
    "revision": "802583c44053f83bcc670e114ec0c183",
    "url": "/namaz/img/bg-m.802583c4.png"
  },
  {
    "revision": "b70b7d6134148d58dc8b8b60d9d93740",
    "url": "/namaz/img/bg-tarawih.b70b7d61.jpg"
  },
  {
    "revision": "6a4e47f1eae510d516e428c73273bcad",
    "url": "/namaz/img/bg.6a4e47f1.jpg"
  },
  {
    "revision": "cad38e6cdbe05c54766dbb3f6d92fb66",
    "url": "/namaz/img/qiyam-woman-2-shaffi.cad38e6c.png"
  },
  {
    "revision": "6bb2d7e501d1f706a93bc6055cc4c8f2",
    "url": "/namaz/img/sadjda-woman-shafii.6bb2d7e5.png"
  },
  {
    "revision": "388ffba707050781d2ce3af9ef833e26",
    "url": "/namaz/img/bg-media.388ffba7.png"
  },
  {
    "revision": "e50d19806e58341f9b6a3cd43588be97",
    "url": "/namaz/img/qiyam-1.e50d1980.png"
  },
  {
    "revision": "18b90d04908192266ece22b4744f83c6",
    "url": "/namaz/img/ruku-1.18b90d04.png"
  },
  {
    "revision": "85fcb0e427ad4f2575f6689dc62153aa",
    "url": "/namaz/img/sadjda-woman.85fcb0e4.png"
  },
  {
    "revision": "23cbe475fffffdacf3f5f8171fae4181",
    "url": "/namaz/img/sitting-woman-1-shafii.23cbe475.png"
  },
  {
    "revision": "ae6d0d86533d3de8f1b75813d708132e",
    "url": "/namaz/img/sitting-woman-2-shafii.ae6d0d86.png"
  },
  {
    "revision": "5a41f6c7d21dca1e7a58f73fec53c97d",
    "url": "/namaz/img/salam-right.5a41f6c7.png"
  },
  {
    "revision": "276dcc8313c9605ad294ce05f546e08f",
    "url": "/namaz/img/niet.276dcc83.png"
  },
  {
    "revision": "4fc278cb8c4db5a1380394c15f960e19",
    "url": "/namaz/img/takbir-1.4fc278cb.png"
  },
  {
    "revision": "769e6db5a06f54fdb93368a4bfef5b26",
    "url": "/namaz/img/qiyam-woman-2.769e6db5.png"
  },
  {
    "revision": "5d31e899b7f169fdb2cd6c47efe14a63",
    "url": "/namaz/img/ruku-2.5d31e899.png"
  },
  {
    "revision": "442199ec9cb3f7c83b76353517b8a3f8",
    "url": "/namaz/img/sadjda.442199ec.png"
  },
  {
    "revision": "45f3a0457e05ee6e2c0d2a8f6f50683a",
    "url": "/namaz/img/sitting-1.45f3a045.png"
  },
  {
    "revision": "dd0aaff151e95818fb73aac29606b7f8",
    "url": "/namaz/img/sitting-woman-1.dd0aaff1.png"
  },
  {
    "revision": "16ebf0b5a2883b036c7e2079f0034282",
    "url": "/namaz/img/sitting-woman-2.16ebf0b5.png"
  },
  {
    "revision": "d0902355a5e04ee5019a0f32f09bbed9",
    "url": "/namaz/img/salam-right-woman-shafii.d0902355.png"
  },
  {
    "revision": "47ceb6645dc5a571e6d83607f212d71d",
    "url": "/namaz/img/salam-right-woman.47ceb664.png"
  },
  {
    "revision": "87e617a9e4f362bd6da8b085ce90e4be",
    "url": "/namaz/img/salam-left-woman-shafii.87e617a9.png"
  },
  {
    "revision": "5063c838f17d7632d7b6dcacf6d38e5a",
    "url": "/namaz/img/salam-left.5063c838.png"
  },
  {
    "revision": "c05b592e05cb744379546292702b03e3",
    "url": "/namaz/img/dua.c05b592e.png"
  },
  {
    "revision": "dc5d2fb49b5cac41c906783a933d22e2",
    "url": "/namaz/img/dua-woman.dc5d2fb4.png"
  },
  {
    "revision": "f313aa4878f0a93ded94a1618246aef6",
    "url": "/namaz/img/dua-woman-shafii.f313aa48.png"
  },
  {
    "revision": "9315ad46ab777b3de6fb1d2869569de5",
    "url": "/namaz/img/niet-shafii.9315ad46.png"
  },
  {
    "revision": "87a6b7c28fe39d590f512ceb1db9e967",
    "url": "/namaz/img/niet-woman-shafii.87a6b7c2.png"
  },
  {
    "revision": "dc98f8e41f719a68868364a535b251e7",
    "url": "/namaz/img/niet-woman.dc98f8e4.png"
  },
  {
    "revision": "8686c7871963e1459478dd1d3b8a2abb",
    "url": "/namaz/img/takbir-woman.8686c787.png"
  },
  {
    "revision": "7f64f58ad09fad218797a05253e644fc",
    "url": "/namaz/img/takbir-woman-shafii.7f64f58a.png"
  },
  {
    "revision": "60509416094e22ab21331ecf06795a46",
    "url": "/namaz/img/qiyam-1-shafii.60509416.png"
  },
  {
    "revision": "e96cdecfe8e0cd861ba820866184d918",
    "url": "/namaz/img/qiyam-woman-1-shaffi.e96cdecf.png"
  },
  {
    "revision": "4ee23e69b94359016fc260c1373056af",
    "url": "/namaz/img/ruku-shafii.4ee23e69.png"
  },
  {
    "revision": "9bf8617de610a51aad37022416040056",
    "url": "/namaz/img/ruku-woman.9bf8617d.png"
  },
  {
    "revision": "d67e559ff56f352dbe61b84b67ae35ae",
    "url": "/namaz/img/ruku-woman-shafii.d67e559f.png"
  },
  {
    "revision": "6f6d625b508858e95fa8",
    "url": "/namaz/js/app.548963ef.js"
  },
  {
    "revision": "2e3f6784b53055759389fe5b8939915f",
    "url": "/namaz/img/sitting-1-shafii.2e3f6784.png"
  },
  {
    "revision": "db63ac9b1ba14712afffcf9c34c6b818",
    "url": "/namaz/img/salam-left-woman.db63ac9b.png"
  },
  {
    "revision": "9866249c4089cc1d6833a1aedb81213c",
    "url": "/namaz/img/dua-shafii.9866249c.png"
  },
  {
    "revision": "eb35df04ade4d9f3416f5a9d759f9ff1",
    "url": "/namaz/img/takbir-1-shafii.eb35df04.png"
  },
  {
    "revision": "12f6c13cfa74b883aa97455e0994c5c9",
    "url": "/namaz/img/qiyam-woman-1.12f6c13c.png"
  },
  {
    "revision": "c4f2308bda9de6d9f0c29382032be2f0",
    "url": "/namaz/img/sitting-2.c4f2308b.png"
  },
  {
    "revision": "c23e8b9c939b11557cf6b2188cc20563",
    "url": "/namaz/img/tashahhud.c23e8b9c.png"
  },
  {
    "revision": "1cd1626f22e44fcd3f5df442d53beb85",
    "url": "/namaz/img/salam-right-shafii.1cd1626f.png"
  },
  {
    "revision": "eb1655b3bc3223ca1c5331f9b1b79cab",
    "url": "/namaz/img/salam-left-shafii.eb1655b3.png"
  },
  {
    "revision": "1e6db010204b3ae8b98547895ba6320c",
    "url": "/namaz/img/ears-and-neck.1e6db010.png"
  },
  {
    "revision": "6d54d12deb8690f587c355b708279056",
    "url": "/namaz/img/qiyam-2.6d54d12d.png"
  },
  {
    "revision": "b2786257a0e6309a98323e9a057213e3",
    "url": "/namaz/img/qiyam-2-shafii.b2786257.png"
  },
  {
    "revision": "830ffd9a3e01b4fe8679b2d18769d848",
    "url": "/namaz/img/tashahhud-woman.830ffd9a.png"
  },
  {
    "revision": "548aee8678465b292c76904797d38845",
    "url": "/namaz/img/ghusl.548aee86.png"
  },
  {
    "revision": "b8ee6451dfbd926e630cb6e4514e9cf9",
    "url": "/namaz/img/tashahhood-shafii.b8ee6451.png"
  },
  {
    "revision": "508fce47893e207090c2c6d9447517dc",
    "url": "/namaz/img/sitting-2-shafii.508fce47.png"
  },
  {
    "revision": "13553cb61cc09151563ee40cdf4eeca2",
    "url": "/namaz/img/mouth.13553cb6.png"
  },
  {
    "revision": "74cae7d469875f3ac5f19a280e004925",
    "url": "/namaz/img/hands.74cae7d4.png"
  },
  {
    "revision": "a7184015521e02e278f019d3141b1d6c",
    "url": "/namaz/img/nose.a7184015.png"
  },
  {
    "revision": "6b7f5ec98f18db1f623268dff95fff10",
    "url": "/namaz/img/face.6b7f5ec9.png"
  },
  {
    "revision": "574d6f549dec58dc8702deeb64dd6a80",
    "url": "/namaz/img/head.574d6f54.png"
  },
  {
    "revision": "ec185e548eeb51af0b306aa743a7f6b5",
    "url": "/namaz/img/dua-shafii.ec185e54.png"
  },
  {
    "revision": "f44ef5a40ece769a9dc40d3ce0307534",
    "url": "/namaz/img/takbir-2-shafii.f44ef5a4.png"
  },
  {
    "revision": "7e1537409a299e64d897d8475ca1a03f",
    "url": "/namaz/img/niet.7e153740.png"
  },
  {
    "revision": "3ef129a708191f8320c711a225b86b7a",
    "url": "/namaz/img/ears-shafii.3ef129a7.png"
  },
  {
    "revision": "f3e2eeaf9f880d087689aeb0dcc6fcc0",
    "url": "/namaz/img/dua.f3e2eeaf.png"
  },
  {
    "revision": "e393d51b201c9f7b4be1a73f15ed0128",
    "url": "/namaz/img/full-hands.e393d51b.png"
  },
  {
    "revision": "bc2b20e68adf100fe847797a1cf6ee02",
    "url": "/namaz/img/niet-shafii.bc2b20e6.png"
  },
  {
    "revision": "4e7d73911086b7cc8615e1de257ee4d2",
    "url": "/namaz/img/full-hands-shafii.4e7d7391.png"
  },
  {
    "revision": "f8457861060f33f71007f45c58f9b077",
    "url": "/namaz/img/head-shafii.f8457861.png"
  },
  {
    "revision": "5a4380d6e7356185a4e4775b179f24fe",
    "url": "/namaz/img/leg-right.5a4380d6.png"
  },
  {
    "revision": "9488c6d29dc1b90cf264af5d5d7da8fa",
    "url": "/namaz/img/takbir-2.9488c6d2.png"
  },
  {
    "revision": "30a3661720b6d9e156e63ba698d6eb9d",
    "url": "/namaz/img/mouth-shafii.30a36617.png"
  },
  {
    "revision": "9cf73b845b001ba50b7b466301890133",
    "url": "/namaz/img/leg-left.9cf73b84.png"
  },
  {
    "revision": "91c26915856354dffa63838d413f14be",
    "url": "/namaz/img/nose-shafii.91c26915.png"
  },
  {
    "revision": "d6019ad74d47a72a1752d14a9cf36d6a",
    "url": "/namaz/img/face-shafii.d6019ad7.png"
  },
  {
    "revision": "9a3b608d0e413f1cca0e5879fb87a6a7",
    "url": "/namaz/img/legs-shafii.9a3b608d.png"
  },
  {
    "revision": "b24d745dccc7eaea8e019c86618ad9f3",
    "url": "/namaz/img/ghusl-bg.b24d745d.jpg"
  },
  {
    "revision": "af60bb5c420446ec90d0e2441d51c890",
    "url": "/namaz/img/taharat-bg.af60bb5c.jpg"
  },
  {
    "revision": "bf1ad711d37ee474540249b27976a0e7",
    "url": "/namaz/img/id-bg.bf1ad711.png"
  },
  {
    "revision": "d17addfde67404ec0757bf75eaac8e74",
    "url": "/namaz/img/ghusl.d17addfd.jpg"
  },
  {
    "revision": "dcfaeebdb595079574b731082fbf6a19",
    "url": "/namaz/img/ghusl.dcfaeebd.jpg"
  },
  {
    "revision": "90451cbf204ab9f4a759a45d5726d873",
    "url": "/namaz/img/fard-fadjr-shafii.90451cbf.jpg"
  },
  {
    "revision": "0115b020010f6290dbe474dda8ac2ae0",
    "url": "/namaz/img/fard-fadjr-woman-shafii.0115b020.jpg"
  },
  {
    "revision": "72fb746c9c5fab2d859d773a37f2c989",
    "url": "/namaz/img/wudu.72fb746c.jpg"
  },
  {
    "revision": "795002a208cf951d34dd38c745c7be14",
    "url": "/namaz/img/wudu-shafii.795002a2.jpg"
  },
  {
    "revision": "4995a6cd2b935601667d3cad763e879c",
    "url": "/namaz/img/fard-fadjr.4995a6cd.jpg"
  },
  {
    "revision": "22a3f8921b36287ad4e355741beef170",
    "url": "/namaz/img/fard-fadjr-woman.22a3f892.jpg"
  },
  {
    "revision": "70c1324ce0ee31695190e99910761a39",
    "url": "/namaz/img/fard-dhuhr-woman-shafii.70c1324c.jpg"
  },
  {
    "revision": "160e8676d352585374e611c8dd8a37dc",
    "url": "/namaz/img/fard-asr.160e8676.jpg"
  },
  {
    "revision": "05d66a40a37120094db5cc582bede7a5",
    "url": "/namaz/img/fard-asr-shafii.05d66a40.jpg"
  },
  {
    "revision": "a8d90ac63d6b337a211808c8fb3bdeb9",
    "url": "/namaz/img/fard-asr-woman-shafii.a8d90ac6.jpg"
  },
  {
    "revision": "abfeaea462440f0d6ab0ddabe3e51d76",
    "url": "/namaz/img/fard-asr-woman.abfeaea4.jpg"
  },
  {
    "revision": "7c91c3c5c05c0acc03fe28fcaf0b27bf",
    "url": "/namaz/img/fard-maghrib.7c91c3c5.jpg"
  },
  {
    "revision": "e9c1f7f00db7e7fee7c5ba84caff1714",
    "url": "/namaz/img/fard-maghrib-shafii.e9c1f7f0.jpg"
  },
  {
    "revision": "5feb8423993a6c30e3de19a464a191c8",
    "url": "/namaz/img/fard-maghrib-woman.5feb8423.jpg"
  },
  {
    "revision": "475dfb74f1398b1c983421524c0c17e8",
    "url": "/namaz/img/fard-maghrib-woman-shafii.475dfb74.jpg"
  },
  {
    "revision": "3008c1aea291323a987f01e52bf2a67b",
    "url": "/namaz/img/fard-isha-shafii.3008c1ae.jpg"
  },
  {
    "revision": "2949dd13a894c32374986b34155f7b8f",
    "url": "/namaz/img/fard-isha-woman.2949dd13.jpg"
  },
  {
    "revision": "298559f03744b1be6dbbb98c1c22c70a",
    "url": "/namaz/img/fard-isha-woman-shafii.298559f0.jpg"
  },
  {
    "revision": "9f25ae163eae35a152c67f4b33ea88a7",
    "url": "/namaz/img/first-namaz-bg.9f25ae16.jpg"
  },
  {
    "revision": "1a400fcd10b8552bfaca47862df099ad",
    "url": "/namaz/img/fard-dhuhr.1a400fcd.jpg"
  },
  {
    "revision": "bc798b4159076115e7acbfafea29229b",
    "url": "/namaz/img/fard-dhuhr-shafii.bc798b41.jpg"
  },
  {
    "revision": "7d7d4f4ef1ca9ef31c28e59e01d8a6e7",
    "url": "/namaz/img/fard-dhuhr-woman.7d7d4f4e.jpg"
  },
  {
    "revision": "a7f987c0d632f0888174d6dd2af3cd54",
    "url": "/namaz/img/fard-isha.a7f987c0.jpg"
  },
  {
    "revision": "0bfc6a21863bd6416b57608b9e4d3440",
    "url": "/namaz/img/masah.0bfc6a21.png"
  },
  {
    "revision": "28a8643e9914fcd9d7e6cb7df6306a99",
    "url": "/namaz/img/ghusl.28a8643e.png"
  },
  {
    "revision": "8192904966ef6807ec812697a632bca8",
    "url": "/namaz/img/namaz-detailed-bg.81929049.jpg"
  },
  {
    "revision": "9b8aaf1bfac0231527ebe74b89d13dbb",
    "url": "/namaz/img/ghusl-m.9b8aaf1b.jpg"
  },
  {
    "revision": "5823e41795bd48b11b5c3ed5b2e6062e",
    "url": "/namaz/img/istibra.5823e417.png"
  },
  {
    "revision": "1516a1fb5c2e5d15220141e580538be7",
    "url": "/namaz/img/ma-hiya.1516a1fb.jpg"
  },
  {
    "revision": "227369bce1caa163c0e0e9bbd7a12b68",
    "url": "/namaz/img/taharat.227369bc.png"
  },
  {
    "revision": "b51e329d5bbd19b81590b0e506e445ae",
    "url": "/namaz/img/taharat-m.b51e329d.jpg"
  },
  {
    "revision": "24fc53177a1729f1f159d4a836511244",
    "url": "/namaz/img/istinja.24fc5317.png"
  },
  {
    "revision": "6a8d8462c5f3c0781c567af89982d100",
    "url": "/namaz/img/aqsaam.6a8d8462.jpg"
  },
  {
    "revision": "d868a678489ae5da9398773170971912",
    "url": "/namaz/img/id.d868a678.png"
  },
  {
    "revision": "375f9c09a1aafbd666e663b4bf9d3e97",
    "url": "/namaz/img/fard-maghrib-m.375f9c09.jpg"
  },
  {
    "revision": "0312d5be6902c0a2bd32600ff6f92da1",
    "url": "/namaz/img/niet-b.0312d5be.png"
  },
  {
    "revision": "a026e30ea07a0129a227c17896dcd4b3",
    "url": "/namaz/img/taharat-shafii.a026e30e.png"
  },
  {
    "revision": "4836a1bcffc36e0bf467bc347e85db3a",
    "url": "/namaz/img/fard-fadjr-m.4836a1bc.jpg"
  },
  {
    "revision": "db5ae63696978ed38e6517a8b7b93fa7",
    "url": "/namaz/img/fard-asr-m.db5ae636.jpg"
  },
  {
    "revision": "e22d36435382494097d9ddaa0f747fce",
    "url": "/namaz/img/fard-isha-m.e22d3643.jpg"
  },
  {
    "revision": "f711c061535e96e3bbab71e743f9d92f",
    "url": "/namaz/img/awrah-b.f711c061.png"
  },
  {
    "revision": "a942b9504ffaf7e8650d048c144a1eb6",
    "url": "/namaz/img/aadaab.a942b950.jpg"
  },
  {
    "revision": "bba685ad48f89ecf43d72eb70496980e",
    "url": "/namaz/img/fasaad.bba685ad.jpg"
  },
  {
    "revision": "a9d0d3129d59bfc2f9665e75ae85462c",
    "url": "/namaz/img/namaz-detailed.a9d0d312.png"
  },
  {
    "revision": "c9140b1f45358a16256a3ba1116bfdfc",
    "url": "/namaz/img/jumuah-m.c9140b1f.jpg"
  },
  {
    "revision": "50f62a1a4be2339d094b8edab673f75f",
    "url": "/namaz/img/id-m.50f62a1a.png"
  },
  {
    "revision": "547a34800b59a4e03e24a545d17ea8f1",
    "url": "/namaz/img/fard-dhuhr-m.547a3480.jpg"
  },
  {
    "revision": "b7e3da84b511880aae44c84933b10ecd",
    "url": "/namaz/img/ma-hiya.b7e3da84.jpg"
  },
  {
    "revision": "e064d8e7b4fd2944a547e714fd0de730",
    "url": "/namaz/img/azan-iqamat.e064d8e7.jpg"
  },
  {
    "revision": "3ac881b1526d94e815ddb1f5fe6d2dc7",
    "url": "/namaz/img/jumuah.3ac881b1.png"
  },
  {
    "revision": "8c91990f9ca3a6b3f5eb0c78cd7d9a9e",
    "url": "/namaz/img/tahharah-b.8c91990f.png"
  },
  {
    "revision": "8abe55f8b971dc157008ea9b1fb6685e",
    "url": "/namaz/img/mareed.8abe55f8.png"
  },
  {
    "revision": "c6c325e1925402d41c7dca0d6529c5ef",
    "url": "/namaz/img/zaman-b.c6c325e1.png"
  },
  {
    "revision": "ecc654ecd36e4f788c397a14f84c776c",
    "url": "/namaz/img/namaz-detailed-woman.ecc654ec.png"
  },
  {
    "revision": "1a3065ff53b677e88991eca8a469525b",
    "url": "/namaz/img/taraweeh.1a3065ff.png"
  },
  {
    "revision": "a4e2381b143bb9a1392d9d95a6295561",
    "url": "/namaz/img/aqsaam.a4e2381b.jpg"
  },
  {
    "revision": "5db626c6fc58e44ce4b7c37c1d33c86e",
    "url": "/namaz/img/shuruut.5db626c6.jpg"
  },
  {
    "revision": "e99b1bd0e8daa58ee34e2e1f4214cc95",
    "url": "/namaz/img/first-namaz-woman.e99b1bd0.png"
  },
  {
    "revision": "cec5ae2d935433ac26b9abf191142525",
    "url": "/namaz/img/first-namaz-woman-shafii.cec5ae2d.png"
  },
  {
    "revision": "60e64cc8ac4a502b0e907fe0a949b55e",
    "url": "/namaz/img/namaz-detailed-woman-shafii.60e64cc8.png"
  },
  {
    "revision": "f0b90ff085a6617bc7f1a54869ac9044",
    "url": "/namaz/img/id.f0b90ff0.png"
  },
  {
    "revision": "6fef64cc8f869b00b829a60eb1000ecb",
    "url": "/namaz/img/namaz-detailed-shafii.6fef64cc.png"
  },
  {
    "revision": "a2df8f4156e91219c8c2d1c5ac6fb7e4",
    "url": "/namaz/img/aadaab.a2df8f41.jpg"
  },
  {
    "revision": "e7df86132e6b919e78db789c22e97a1e",
    "url": "/namaz/img/qiblah-b.e7df8613.png"
  },
  {
    "revision": "41f09d543870767fde4b6917fb3948c5",
    "url": "/namaz/img/jumuah.41f09d54.png"
  },
  {
    "revision": "91196c820205be2dc6d078ec021ae12b",
    "url": "/namaz/img/taraweeh.91196c82.png"
  },
  {
    "revision": "2d833f64352ca7e6c65338088c7a48a1",
    "url": "/namaz/img/fasaad.2d833f64.jpg"
  },
  {
    "revision": "fcdfbac4485ab7343722ba0bc40f5944",
    "url": "/namaz/img/first-namaz-shafii.fcdfbac4.png"
  },
  {
    "revision": "7fe95252711a489268e88607e63f994c",
    "url": "/namaz/img/first-namaz.7fe95252.png"
  },
  {
    "revision": "8f4c86e357fc101cfcfff151e5056f17",
    "url": "/namaz/img/taraweeh-m.8f4c86e3.jpg"
  },
  {
    "revision": "6393cc7eeb180d44d0be78454482259e",
    "url": "/namaz/img/makan-b.6393cc7e.png"
  },
  {
    "revision": "f3ef1bc756b441a05796a8a78a6a4a59",
    "url": "/namaz/img/tayammum.f3ef1bc7.png"
  },
  {
    "revision": "97cd734d12ad4f2d68c255760f809f81",
    "url": "/namaz/img/tahharah.97cd734d.png"
  },
  {
    "revision": "84918fdfc0a630c8aec256e657028cbc",
    "url": "/namaz/img/zaman-bg.84918fdf.png"
  },
  {
    "revision": "cf35c5cf35541c9275f209dc79a12927",
    "url": "/namaz/img/qiblah-bg.cf35c5cf.png"
  },
  {
    "revision": "f2ebfedc738c3c03e337c7911d735f8b",
    "url": "/namaz/img/awrah.f2ebfedc.png"
  },
  {
    "revision": "b46017689c0b78abd49b940994863355",
    "url": "/namaz/img/niet.b4601768.png"
  },
  {
    "revision": "ede875ccb0696d4610f8250d3cb9fe50",
    "url": "/namaz/img/first-namaz-bg-m.ede875cc.png"
  },
  {
    "revision": "5c55b37ff1afed7c2e2d687400e2cd86",
    "url": "/namaz/img/makan.5c55b37f.png"
  },
  {
    "revision": "790ca2bf71ad1b52c965ac6a2f62daf9",
    "url": "/namaz/img/qiblah.790ca2bf.png"
  },
  {
    "revision": "7d0a4c841492dc7968f131d4f234fa40",
    "url": "/namaz/img/azan-iqamat-bg.7d0a4c84.png"
  },
  {
    "revision": "df8e53b5240b606c16777d427e27c251",
    "url": "/namaz/img/tutoring-bg.df8e53b5.jpg"
  },
  {
    "revision": "9515c12420e274408436f206f10c8158",
    "url": "/namaz/img/top-bg.9515c124.png"
  },
  {
    "revision": "c04359e1548b6800f0be80a4a7c79c82",
    "url": "/namaz/img/bottom-bg.c04359e1.png"
  },
  {
    "revision": "1b7949e90cbeb468879f1b486ce122c7",
    "url": "/namaz/img/top-bg-m.1b7949e9.png"
  },
  {
    "revision": "98edd71d4bacc0c066f0a0e9b38156af",
    "url": "/namaz/img/bottom-bg-m.98edd71d.png"
  },
  {
    "revision": "c41d8b67939780b981c1bba8b058f658",
    "url": "/namaz/img/taharat-bg.c41d8b67.jpg"
  },
  {
    "revision": "c81f0ea21dc9862a258361f453700059",
    "url": "/namaz/img/istibra.c81f0ea2.png"
  },
  {
    "revision": "d0028c90db6f912edc5dee8f358c59b3",
    "url": "/namaz/img/istinja.d0028c90.png"
  },
  {
    "revision": "03d481710d80ec5200a1e0294efdebcb",
    "url": "/namaz/img/ghusl.03d48171.png"
  },
  {
    "revision": "79d65d134cdc99a25889f9870ccd4ef5",
    "url": "/namaz/icons/icon-167x167.png"
  },
  {
    "revision": "819cf90e93b09498b1a5",
    "url": "/namaz/css/wudu.e174c163.css"
  },
  {
    "revision": "e75a2ac85c95fe28b8926be1bf7159d0",
    "url": "/namaz/images/namaz/mareed/qiyam.png"
  },
  {
    "revision": "77ee3a0ef60dbdb3d92ab0aa69906c75",
    "url": "/namaz/images/namaz/mareed/sadjda.png"
  },
  {
    "revision": "c8916eda882f2653f7458f68cdb3c087",
    "url": "/namaz/images/namaz/mareed/ruku.png"
  },
  {
    "revision": "2cbc696771ca9f0b20ef5b67bcfaee00",
    "url": "/namaz/icons/icon-48x48.png"
  },
  {
    "revision": "5f7bf862f590f500d6bcbbdd876f85f4",
    "url": "/namaz/icons/icon-120x120.png"
  },
  {
    "revision": "7c4a1adbfbb17e9065e1e400f33ae5dd",
    "url": "/namaz/icons/icon-96x96.png"
  },
  {
    "revision": "049bedac8a257c7e85e70eed21db1d49",
    "url": "/namaz/icons/icon-152x152.png"
  },
  {
    "revision": "f3089c45870651769abd6891f591cbf5",
    "url": "/namaz/icons/icon-144x144.png"
  },
  {
    "revision": "4d7693f06a860d8aa600fb5d901e8e7c",
    "url": "/namaz/images/namaz/mareed/qiraat.png"
  },
  {
    "revision": "2ee71d6d62125d8b9479c4508208f1ec",
    "url": "/namaz/icons/icon-180x180.png"
  },
  {
    "revision": "8c1f04c8681ec1a864eeb1af5e7596b5",
    "url": "/namaz/icons/icon-192x192.png"
  },
  {
    "revision": "df787045eed4dbb5a79de6cd35d5b67a",
    "url": "/namaz/images/namaz/mareed/dua.png"
  },
  {
    "revision": "b21162d2a3e9a4e41de8",
    "url": "/namaz/css/tahharah.08089a8f.css"
  },
  {
    "revision": "d14fb15881254019ded1",
    "url": "/namaz/css/solaatil-uulaa.808938aa.css"
  },
  {
    "revision": "09484bc8ae8847b16756",
    "url": "/namaz/css/shart.302c3162.css"
  },
  {
    "revision": "e1a2bbbf0fabc48e7383",
    "url": "/namaz/css/namaz~tahharah~wudu.bf435538.css"
  },
  {
    "revision": "b19475736d0ce634644d",
    "url": "/namaz/css/namaz~solaatil-uulaa~wudu.ba5bd628.css"
  },
  {
    "revision": "15f210ce7b85823aa339",
    "url": "/namaz/css/namaz.3f312582.css"
  },
  {
    "revision": "6f6d625b508858e95fa8",
    "url": "/namaz/css/app.beaeab8c.css"
  }
];