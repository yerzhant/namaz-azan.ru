self.__precacheManifest = [
  {
    "revision": "94a042b82b418d86d5eb4cfa2453730b",
    "url": "/namaz/img/full-bg.94a042b8.png"
  },
  {
    "revision": "a669b634494d8603cfe55d2fac1182e6",
    "url": "/namaz/index.html"
  },
  {
    "revision": "70c35b7642ac0d4ac193",
    "url": "/namaz/js/chunk-vendors-legacy.28879b70.js"
  },
  {
    "revision": "68e18937bc0845ead9ea",
    "url": "/namaz/js/app-legacy.9b896c18.js"
  },
  {
    "revision": "1391764beb6b241f74a6",
    "url": "/namaz/js/namaz-legacy.34f4d32a.js"
  },
  {
    "revision": "6427965b1aa4ec60e439",
    "url": "/namaz/js/wudu-legacy.d1620734.js"
  },
  {
    "revision": "0542b66751fb4309cf51",
    "url": "/namaz/js/namaz~solaatil-uulaa~wudu-legacy.e2a92a07.js"
  },
  {
    "revision": "5bb40939f4cf65834fca",
    "url": "/namaz/js/tahharah-legacy.664bb338.js"
  },
  {
    "revision": "be67d3570daa0595844e",
    "url": "/namaz/js/namaz~tahharah~wudu-legacy.2293993a.js"
  },
  {
    "revision": "92a1a600e37a5daae104",
    "url": "/namaz/js/solaatil-uulaa-legacy.7ca2404a.js"
  },
  {
    "revision": "d9afb6d3f4e68aaf8ace",
    "url": "/namaz/js/shart-legacy.af9fa117.js"
  },
  {
    "revision": "08734e35ac5070a6d4dbfc276c867aa2",
    "url": "/namaz/img/asr-bg-w.08734e35.png"
  },
  {
    "revision": "92a1a600e37a5daae104",
    "url": "/namaz/css/solaatil-uulaa.2a1f55c5.css"
  },
  {
    "revision": "5bb40939f4cf65834fca",
    "url": "/namaz/css/tahharah.b63e1336.css"
  },
  {
    "revision": "c41d8b67939780b981c1bba8b058f658",
    "url": "/namaz/img/taharat-bg.c41d8b67.jpg"
  },
  {
    "revision": "6427965b1aa4ec60e439",
    "url": "/namaz/css/wudu.97e712dd.css"
  },
  {
    "revision": "b69e23d573b3c22f16eb7a4051d3d27f",
    "url": "/namaz/img/masah.b69e23d5.png"
  },
  {
    "revision": "10f5222ae488f897ea11abee8069f750",
    "url": "/namaz/img/bg.10f5222a.png"
  },
  {
    "revision": "653ff28969ed88ffd21a347db5bdab41",
    "url": "/namaz/img/ma-hiya.653ff289.jpg"
  },
  {
    "revision": "20df3b25dc8ae9150e898a2645e020ea",
    "url": "/namaz/img/aqsaam.20df3b25.jpg"
  },
  {
    "revision": "ba9e4c0eaf3578b3f01d64870a5d979f",
    "url": "/namaz/img/shuruut.ba9e4c0e.jpg"
  },
  {
    "revision": "f82b7b05ef3af6e85da56996636b4b21",
    "url": "/namaz/img/azan-iqamat.f82b7b05.jpg"
  },
  {
    "revision": "91c63017730a07a6a34138e3a7a05f54",
    "url": "/namaz/img/aadaab.91c63017.jpg"
  },
  {
    "revision": "c1517262328d26f0b24a17ae5c6a437c",
    "url": "/namaz/img/fasaad.c1517262.jpg"
  },
  {
    "revision": "5de49986d5180d95aee78fd642a908d5",
    "url": "/namaz/img/buttons-bg.5de49986.jpg"
  },
  {
    "revision": "700539a8d8ec66f6d98f3b92a92768af",
    "url": "/namaz/img/select-bg.700539a8.png"
  },
  {
    "revision": "a7e3a7cc6d5096dbb61f894ca1b36494",
    "url": "/namaz/img/select-bg.a7e3a7cc.jpg"
  },
  {
    "revision": "27415876c269ba21d16a82b6e7d6aa3b",
    "url": "/namaz/img/woman.27415876.png"
  },
  {
    "revision": "afc593f0d4c2436f2a221fade46468ce",
    "url": "/namaz/img/man.afc593f0.png"
  },
  {
    "revision": "075f0e40a5bbdd509e78f6e20223c3f7",
    "url": "/namaz/img/footer-bg.075f0e40.png"
  },
  {
    "revision": "7a830b090f83365b13885fcdd9a7e06d",
    "url": "/namaz/img/footer-bg-m.7a830b09.png"
  },
  {
    "revision": "ee23a4311e9aa695380d53f012611921",
    "url": "/namaz/img/image-bg-m.ee23a431.jpg"
  },
  {
    "revision": "49c3d35b69f0a06414994837dd443c43",
    "url": "/namaz/img/man-m.49c3d35b.png"
  },
  {
    "revision": "cfa89f32081a0807c4794b9617385625",
    "url": "/namaz/img/woman-m.cfa89f32.png"
  },
  {
    "revision": "2849117748183276c02ce972bcccabcf",
    "url": "/namaz/img/fadjr-bg.28491177.jpg"
  },
  {
    "revision": "44e80c93375881ec073a876b454a02ec",
    "url": "/namaz/img/dhuhr-bg.44e80c93.jpg"
  },
  {
    "revision": "adbf8da615195e6f7e9d992a7489822f",
    "url": "/namaz/img/asr-bg.adbf8da6.jpg"
  },
  {
    "revision": "9d30f63b8e07a1c9611d9718da926641",
    "url": "/namaz/img/maghrib-bg.9d30f63b.jpg"
  },
  {
    "revision": "ceff74c4332e05b7b2f33ec77bbf20b5",
    "url": "/namaz/img/isha-bg.ceff74c4.jpg"
  },
  {
    "revision": "67321d4c74f458a284fa670db67dd038",
    "url": "/namaz/img/witr-bg.67321d4c.jpg"
  },
  {
    "revision": "cd25dcfbf6c74eebc432edc12b1860b6",
    "url": "/namaz/img/bg.cd25dcfb.png"
  },
  {
    "revision": "802583c44053f83bcc670e114ec0c183",
    "url": "/namaz/img/bg-m.802583c4.png"
  },
  {
    "revision": "5dcca553fc4174905664944fdf6789ae",
    "url": "/namaz/img/bg-small.5dcca553.png"
  },
  {
    "revision": "8e2171964f280fe4184d2406623c3bf7",
    "url": "/namaz/img/bg-small-witr.8e217196.png"
  },
  {
    "revision": "301d9ff1a28567425502bce03ab1f789",
    "url": "/namaz/img/bg-small-asr.301d9ff1.png"
  },
  {
    "revision": "6b728a4180e5a00ba2c614886e23af47",
    "url": "/namaz/img/bg-fadjr.6b728a41.jpg"
  },
  {
    "revision": "10279c47a930c9e51a3f950231e58c9f",
    "url": "/namaz/img/bg-dhuhr.10279c47.jpg"
  },
  {
    "revision": "b4625a0dd2f120bed1f4e40d3daaa2a4",
    "url": "/namaz/img/bg-asr.b4625a0d.jpg"
  },
  {
    "revision": "33490bd9aeb22ac326d68557f77ae465",
    "url": "/namaz/img/bg-maghrib.33490bd9.jpg"
  },
  {
    "revision": "9f4f237567c137c1ba3c4424692acb49",
    "url": "/namaz/img/bg-isha.9f4f2375.jpg"
  },
  {
    "revision": "192040453a59ed6f1c879047230a337f",
    "url": "/namaz/img/bg-witr.19204045.jpg"
  },
  {
    "revision": "388ffba707050781d2ce3af9ef833e26",
    "url": "/namaz/img/bg-media.388ffba7.png"
  },
  {
    "revision": "276dcc8313c9605ad294ce05f546e08f",
    "url": "/namaz/img/niet.276dcc83.png"
  },
  {
    "revision": "dc98f8e41f719a68868364a535b251e7",
    "url": "/namaz/img/niet-woman.dc98f8e4.png"
  },
  {
    "revision": "4fc278cb8c4db5a1380394c15f960e19",
    "url": "/namaz/img/takbir-1.4fc278cb.png"
  },
  {
    "revision": "8686c7871963e1459478dd1d3b8a2abb",
    "url": "/namaz/img/takbir-woman.8686c787.png"
  },
  {
    "revision": "9488c6d29dc1b90cf264af5d5d7da8fa",
    "url": "/namaz/img/takbir-2.9488c6d2.png"
  },
  {
    "revision": "e50d19806e58341f9b6a3cd43588be97",
    "url": "/namaz/img/qiyam-1.e50d1980.png"
  },
  {
    "revision": "12f6c13cfa74b883aa97455e0994c5c9",
    "url": "/namaz/img/qiyam-woman-1.12f6c13c.png"
  },
  {
    "revision": "6d54d12deb8690f587c355b708279056",
    "url": "/namaz/img/qiyam-2.6d54d12d.png"
  },
  {
    "revision": "769e6db5a06f54fdb93368a4bfef5b26",
    "url": "/namaz/img/qiyam-woman-2.769e6db5.png"
  },
  {
    "revision": "18b90d04908192266ece22b4744f83c6",
    "url": "/namaz/img/ruku-1.18b90d04.png"
  },
  {
    "revision": "9bf8617de610a51aad37022416040056",
    "url": "/namaz/img/ruku-woman.9bf8617d.png"
  },
  {
    "revision": "5d31e899b7f169fdb2cd6c47efe14a63",
    "url": "/namaz/img/ruku-2.5d31e899.png"
  },
  {
    "revision": "442199ec9cb3f7c83b76353517b8a3f8",
    "url": "/namaz/img/sadjda.442199ec.png"
  },
  {
    "revision": "85fcb0e427ad4f2575f6689dc62153aa",
    "url": "/namaz/img/sadjda-woman.85fcb0e4.png"
  },
  {
    "revision": "45f3a0457e05ee6e2c0d2a8f6f50683a",
    "url": "/namaz/img/sitting-1.45f3a045.png"
  },
  {
    "revision": "dd0aaff151e95818fb73aac29606b7f8",
    "url": "/namaz/img/sitting-woman-1.dd0aaff1.png"
  },
  {
    "revision": "c4f2308bda9de6d9f0c29382032be2f0",
    "url": "/namaz/img/sitting-2.c4f2308b.png"
  },
  {
    "revision": "16ebf0b5a2883b036c7e2079f0034282",
    "url": "/namaz/img/sitting-woman-2.16ebf0b5.png"
  },
  {
    "revision": "c23e8b9c939b11557cf6b2188cc20563",
    "url": "/namaz/img/tashahhud.c23e8b9c.png"
  },
  {
    "revision": "830ffd9a3e01b4fe8679b2d18769d848",
    "url": "/namaz/img/tashahhud-woman.830ffd9a.png"
  },
  {
    "revision": "5a41f6c7d21dca1e7a58f73fec53c97d",
    "url": "/namaz/img/salam-right.5a41f6c7.png"
  },
  {
    "revision": "47ceb6645dc5a571e6d83607f212d71d",
    "url": "/namaz/img/salam-right-woman.47ceb664.png"
  },
  {
    "revision": "5063c838f17d7632d7b6dcacf6d38e5a",
    "url": "/namaz/img/salam-left.5063c838.png"
  },
  {
    "revision": "db63ac9b1ba14712afffcf9c34c6b818",
    "url": "/namaz/img/salam-left-woman.db63ac9b.png"
  },
  {
    "revision": "c05b592e05cb744379546292702b03e3",
    "url": "/namaz/img/dua.c05b592e.png"
  },
  {
    "revision": "dc5d2fb49b5cac41c906783a933d22e2",
    "url": "/namaz/img/dua-woman.dc5d2fb4.png"
  },
  {
    "revision": "548aee8678465b292c76904797d38845",
    "url": "/namaz/img/ghusl.548aee86.png"
  },
  {
    "revision": "7e1537409a299e64d897d8475ca1a03f",
    "url": "/namaz/img/niet.7e153740.png"
  },
  {
    "revision": "74cae7d469875f3ac5f19a280e004925",
    "url": "/namaz/img/hands.74cae7d4.png"
  },
  {
    "revision": "13553cb61cc09151563ee40cdf4eeca2",
    "url": "/namaz/img/mouth.13553cb6.png"
  },
  {
    "revision": "a7184015521e02e278f019d3141b1d6c",
    "url": "/namaz/img/nose.a7184015.png"
  },
  {
    "revision": "6b7f5ec98f18db1f623268dff95fff10",
    "url": "/namaz/img/face.6b7f5ec9.png"
  },
  {
    "revision": "e393d51b201c9f7b4be1a73f15ed0128",
    "url": "/namaz/img/full-hands.e393d51b.png"
  },
  {
    "revision": "574d6f549dec58dc8702deeb64dd6a80",
    "url": "/namaz/img/head.574d6f54.png"
  },
  {
    "revision": "1e6db010204b3ae8b98547895ba6320c",
    "url": "/namaz/img/ears-and-neck.1e6db010.png"
  },
  {
    "revision": "5a4380d6e7356185a4e4775b179f24fe",
    "url": "/namaz/img/leg-right.5a4380d6.png"
  },
  {
    "revision": "9cf73b845b001ba50b7b466301890133",
    "url": "/namaz/img/leg-left.9cf73b84.png"
  },
  {
    "revision": "f3e2eeaf9f880d087689aeb0dcc6fcc0",
    "url": "/namaz/img/dua.f3e2eeaf.png"
  },
  {
    "revision": "c81f0ea21dc9862a258361f453700059",
    "url": "/namaz/img/istibra.c81f0ea2.png"
  },
  {
    "revision": "d0028c90db6f912edc5dee8f358c59b3",
    "url": "/namaz/img/istinja.d0028c90.png"
  },
  {
    "revision": "7590d43a0e91371db365bb3b6cc95208",
    "url": "/namaz/img/tayammum.7590d43a.png"
  },
  {
    "revision": "03d481710d80ec5200a1e0294efdebcb",
    "url": "/namaz/img/ghusl.03d48171.png"
  },
  {
    "revision": "d5f1b98baa9f492e9f71d390e2742b5d",
    "url": "/namaz/img/wudu.d5f1b98b.png"
  },
  {
    "revision": "ccc5239303e815d33c3547f26861041a",
    "url": "/namaz/img/masah.ccc52393.png"
  },
  {
    "revision": "e927158f7a6da75e0dc6aed09e4a53b8",
    "url": "/namaz/img/bg.e927158f.png"
  },
  {
    "revision": "8ff1054cbacdca34d72e2a924bacaaf5",
    "url": "/namaz/img/bg-fadjr.8ff1054c.png"
  },
  {
    "revision": "ce1c3786b650426ed1d41268c59aae3b",
    "url": "/namaz/img/bg-dhuhr.ce1c3786.png"
  },
  {
    "revision": "220ed6381278445607c2f350b20fb6e5",
    "url": "/namaz/img/bg-asr.220ed638.png"
  },
  {
    "revision": "89edb135c109c2d4f005730156312601",
    "url": "/namaz/img/bg-maghrib.89edb135.png"
  },
  {
    "revision": "881d9fbb6ae8854fe947837f563c109f",
    "url": "/namaz/img/bg-isha.881d9fbb.png"
  },
  {
    "revision": "e451a6ef831989febdd9b8e332da3d4b",
    "url": "/namaz/img/tayammum.e451a6ef.png"
  },
  {
    "revision": "773f31cab0957771267bf012b0dd04df",
    "url": "/namaz/img/bg-witr.773f31ca.png"
  },
  {
    "revision": "8ff732f6887afb540b5a96cb6c46430a",
    "url": "/namaz/img/fadjr-bg.8ff732f6.png"
  },
  {
    "revision": "397b36e6a413b80807e4e7b34e9cbac3",
    "url": "/namaz/img/fadjr-bg-w.397b36e6.png"
  },
  {
    "revision": "2940b7d4719962b35af49e6308b3268e",
    "url": "/namaz/img/dhuhr-bg-m.2940b7d4.png"
  },
  {
    "revision": "38edcbf4ff91bcc6ff55e93593dc4ad8",
    "url": "/namaz/img/dhuhr-bg-w.38edcbf4.png"
  },
  {
    "revision": "176b80b3152358a9a08bd4955c26009b",
    "url": "/namaz/img/istinja.176b80b3.png"
  },
  {
    "revision": "c27505a9d76c7f112459066d7f69ed81",
    "url": "/namaz/img/asr-bg.c27505a9.png"
  },
  {
    "revision": "30f21fe6590126b70ef6cb4a52866916",
    "url": "/namaz/img/maghrib-bg.30f21fe6.png"
  },
  {
    "revision": "5de99373b049835a4b016a6993c19e0f",
    "url": "/namaz/img/maghrib-bg-w.5de99373.png"
  },
  {
    "revision": "6dad5ce2e5eae7c624d6c55d8e336256",
    "url": "/namaz/img/dhuhr-bg.6dad5ce2.png"
  },
  {
    "revision": "87b97ed72e9740c5bd3f3298fa83c688",
    "url": "/namaz/img/isha-bg.87b97ed7.png"
  },
  {
    "revision": "5e70bf8482d33e5332e4f21aeb77805b",
    "url": "/namaz/img/isha-bg-w.5e70bf84.png"
  },
  {
    "revision": "a45014fecc09e99d705132f5cdf896d6",
    "url": "/namaz/img/witr-bg.a45014fe.png"
  },
  {
    "revision": "34f7221c5170b722d027492aae499782",
    "url": "/namaz/img/witr-bg-w.34f7221c.png"
  },
  {
    "revision": "5469ebc48a0e46ef1e21ca81445cc4b1",
    "url": "/namaz/img/jumuah-bg.5469ebc4.png"
  },
  {
    "revision": "c9dd5570dbe36df0ac18a65ae178b460",
    "url": "/namaz/img/wudu-bg.c9dd5570.png"
  },
  {
    "revision": "13c61ce464512830ece511ffb0b04844",
    "url": "/namaz/img/ghusl-bg.13c61ce4.png"
  },
  {
    "revision": "71060f4b047a2400cd50a54431f91b4e",
    "url": "/namaz/img/istibra-bg.71060f4b.png"
  },
  {
    "revision": "06b048a11d14d557e4f56c2330aac3cd",
    "url": "/namaz/img/istinja-bg.06b048a1.png"
  },
  {
    "revision": "74e05fb1fea4d3a3eabedec1e36fd3f6",
    "url": "/namaz/img/tayammum-bg.74e05fb1.png"
  },
  {
    "revision": "3ea7b9be1b65959c002d08bd4ba52d69",
    "url": "/namaz/img/masah-bg.3ea7b9be.png"
  },
  {
    "revision": "25557e57fda71d5cdde86c2893c44372",
    "url": "/namaz/img/section-bg.25557e57.png"
  },
  {
    "revision": "9515c12420e274408436f206f10c8158",
    "url": "/namaz/img/top-bg.9515c124.png"
  },
  {
    "revision": "1b7949e90cbeb468879f1b486ce122c7",
    "url": "/namaz/img/top-bg-m.1b7949e9.png"
  },
  {
    "revision": "c04359e1548b6800f0be80a4a7c79c82",
    "url": "/namaz/img/bottom-bg.c04359e1.png"
  },
  {
    "revision": "98edd71d4bacc0c066f0a0e9b38156af",
    "url": "/namaz/img/bottom-bg-m.98edd71d.png"
  },
  {
    "revision": "6962ac7458bc247a2bad3175d367817b",
    "url": "/namaz/img/namaz-bg.6962ac74.jpg"
  },
  {
    "revision": "6a4e47f1eae510d516e428c73273bcad",
    "url": "/namaz/img/bg.6a4e47f1.jpg"
  },
  {
    "revision": "df8e53b5240b606c16777d427e27c251",
    "url": "/namaz/img/tutoring-bg.df8e53b5.jpg"
  },
  {
    "revision": "9f25ae163eae35a152c67f4b33ea88a7",
    "url": "/namaz/img/first-namaz-bg.9f25ae16.jpg"
  },
  {
    "revision": "ede875ccb0696d4610f8250d3cb9fe50",
    "url": "/namaz/img/first-namaz-bg-m.ede875cc.png"
  },
  {
    "revision": "7fe95252711a489268e88607e63f994c",
    "url": "/namaz/img/first-namaz.7fe95252.png"
  },
  {
    "revision": "e99b1bd0e8daa58ee34e2e1f4214cc95",
    "url": "/namaz/img/first-namaz-woman.e99b1bd0.png"
  },
  {
    "revision": "8192904966ef6807ec812697a632bca8",
    "url": "/namaz/img/namaz-detailed-bg.81929049.jpg"
  },
  {
    "revision": "a9d0d3129d59bfc2f9665e75ae85462c",
    "url": "/namaz/img/namaz-detailed.a9d0d312.png"
  },
  {
    "revision": "ecc654ecd36e4f788c397a14f84c776c",
    "url": "/namaz/img/namaz-detailed-woman.ecc654ec.png"
  },
  {
    "revision": "b24d745dccc7eaea8e019c86618ad9f3",
    "url": "/namaz/img/ghusl-bg.b24d745d.jpg"
  },
  {
    "revision": "28a8643e9914fcd9d7e6cb7df6306a99",
    "url": "/namaz/img/ghusl.28a8643e.png"
  },
  {
    "revision": "9b8aaf1bfac0231527ebe74b89d13dbb",
    "url": "/namaz/img/ghusl-m.9b8aaf1b.jpg"
  },
  {
    "revision": "af60bb5c420446ec90d0e2441d51c890",
    "url": "/namaz/img/taharat-bg.af60bb5c.jpg"
  },
  {
    "revision": "227369bce1caa163c0e0e9bbd7a12b68",
    "url": "/namaz/img/taharat.227369bc.png"
  },
  {
    "revision": "b51e329d5bbd19b81590b0e506e445ae",
    "url": "/namaz/img/taharat-m.b51e329d.jpg"
  },
  {
    "revision": "4995a6cd2b935601667d3cad763e879c",
    "url": "/namaz/img/fard-fadjr.4995a6cd.jpg"
  },
  {
    "revision": "4836a1bcffc36e0bf467bc347e85db3a",
    "url": "/namaz/img/fard-fadjr-m.4836a1bc.jpg"
  },
  {
    "revision": "22a3f8921b36287ad4e355741beef170",
    "url": "/namaz/img/fard-fadjr-woman.22a3f892.jpg"
  },
  {
    "revision": "1a400fcd10b8552bfaca47862df099ad",
    "url": "/namaz/img/fard-dhuhr.1a400fcd.jpg"
  },
  {
    "revision": "547a34800b59a4e03e24a545d17ea8f1",
    "url": "/namaz/img/fard-dhuhr-m.547a3480.jpg"
  },
  {
    "revision": "7d7d4f4ef1ca9ef31c28e59e01d8a6e7",
    "url": "/namaz/img/fard-dhuhr-woman.7d7d4f4e.jpg"
  },
  {
    "revision": "160e8676d352585374e611c8dd8a37dc",
    "url": "/namaz/img/fard-asr.160e8676.jpg"
  },
  {
    "revision": "db5ae63696978ed38e6517a8b7b93fa7",
    "url": "/namaz/img/fard-asr-m.db5ae636.jpg"
  },
  {
    "revision": "abfeaea462440f0d6ab0ddabe3e51d76",
    "url": "/namaz/img/fard-asr-woman.abfeaea4.jpg"
  },
  {
    "revision": "7c91c3c5c05c0acc03fe28fcaf0b27bf",
    "url": "/namaz/img/fard-maghrib.7c91c3c5.jpg"
  },
  {
    "revision": "375f9c09a1aafbd666e663b4bf9d3e97",
    "url": "/namaz/img/fard-maghrib-m.375f9c09.jpg"
  },
  {
    "revision": "5feb8423993a6c30e3de19a464a191c8",
    "url": "/namaz/img/fard-maghrib-woman.5feb8423.jpg"
  },
  {
    "revision": "a7f987c0d632f0888174d6dd2af3cd54",
    "url": "/namaz/img/fard-isha.a7f987c0.jpg"
  },
  {
    "revision": "e22d36435382494097d9ddaa0f747fce",
    "url": "/namaz/img/fard-isha-m.e22d3643.jpg"
  },
  {
    "revision": "2949dd13a894c32374986b34155f7b8f",
    "url": "/namaz/img/fard-isha-woman.2949dd13.jpg"
  },
  {
    "revision": "72fb746c9c5fab2d859d773a37f2c989",
    "url": "/namaz/img/wudu.72fb746c.jpg"
  },
  {
    "revision": "d17addfde67404ec0757bf75eaac8e74",
    "url": "/namaz/img/ghusl.d17addfd.jpg"
  },
  {
    "revision": "6393cc7eeb180d44d0be78454482259e",
    "url": "/namaz/img/makan-b.6393cc7e.png"
  },
  {
    "revision": "8c91990f9ca3a6b3f5eb0c78cd7d9a9e",
    "url": "/namaz/img/tahharah-b.8c91990f.png"
  },
  {
    "revision": "f711c061535e96e3bbab71e743f9d92f",
    "url": "/namaz/img/awrah-b.f711c061.png"
  },
  {
    "revision": "e7df86132e6b919e78db789c22e97a1e",
    "url": "/namaz/img/qiblah-b.e7df8613.png"
  },
  {
    "revision": "c6c325e1925402d41c7dca0d6529c5ef",
    "url": "/namaz/img/zaman-b.c6c325e1.png"
  },
  {
    "revision": "0312d5be6902c0a2bd32600ff6f92da1",
    "url": "/namaz/img/niet-b.0312d5be.png"
  },
  {
    "revision": "dcfaeebdb595079574b731082fbf6a19",
    "url": "/namaz/img/ghusl.dcfaeebd.jpg"
  },
  {
    "revision": "5823e41795bd48b11b5c3ed5b2e6062e",
    "url": "/namaz/img/istibra.5823e417.png"
  },
  {
    "revision": "24fc53177a1729f1f159d4a836511244",
    "url": "/namaz/img/istinja.24fc5317.png"
  },
  {
    "revision": "f3ef1bc756b441a05796a8a78a6a4a59",
    "url": "/namaz/img/tayammum.f3ef1bc7.png"
  },
  {
    "revision": "0bfc6a21863bd6416b57608b9e4d3440",
    "url": "/namaz/img/masah.0bfc6a21.png"
  },
  {
    "revision": "5c55b37ff1afed7c2e2d687400e2cd86",
    "url": "/namaz/img/makan.5c55b37f.png"
  },
  {
    "revision": "97cd734d12ad4f2d68c255760f809f81",
    "url": "/namaz/img/tahharah.97cd734d.png"
  },
  {
    "revision": "f2ebfedc738c3c03e337c7911d735f8b",
    "url": "/namaz/img/awrah.f2ebfedc.png"
  },
  {
    "revision": "cf35c5cf35541c9275f209dc79a12927",
    "url": "/namaz/img/qiblah-bg.cf35c5cf.png"
  },
  {
    "revision": "790ca2bf71ad1b52c965ac6a2f62daf9",
    "url": "/namaz/img/qiblah.790ca2bf.png"
  },
  {
    "revision": "84918fdfc0a630c8aec256e657028cbc",
    "url": "/namaz/img/zaman-bg.84918fdf.png"
  },
  {
    "revision": "b46017689c0b78abd49b940994863355",
    "url": "/namaz/img/niet.b4601768.png"
  },
  {
    "revision": "7d0a4c841492dc7968f131d4f234fa40",
    "url": "/namaz/img/azan-iqamat-bg.7d0a4c84.png"
  },
  {
    "revision": "b7e3da84b511880aae44c84933b10ecd",
    "url": "/namaz/img/ma-hiya.b7e3da84.jpg"
  },
  {
    "revision": "a4e2381b143bb9a1392d9d95a6295561",
    "url": "/namaz/img/aqsaam.a4e2381b.jpg"
  },
  {
    "revision": "d374a963a283830a216b3a0f44f86aa5",
    "url": "/namaz/img/azan-iqamat.d374a963.jpg"
  },
  {
    "revision": "a2df8f4156e91219c8c2d1c5ac6fb7e4",
    "url": "/namaz/img/aadaab.a2df8f41.jpg"
  },
  {
    "revision": "2d833f64352ca7e6c65338088c7a48a1",
    "url": "/namaz/img/fasaad.2d833f64.jpg"
  },
  {
    "revision": "944316af7e6d4a9a4d774c1ff9e67805",
    "url": "/namaz/img/fadjr.944316af.jpg"
  },
  {
    "revision": "d2846aee06673e065c31e8ce2a82a49f",
    "url": "/namaz/img/fadjr-w.d2846aee.jpg"
  },
  {
    "revision": "68bd2e9c04db7e600c162dd9d8916443",
    "url": "/namaz/img/dhuhr.68bd2e9c.jpg"
  },
  {
    "revision": "8cd323c2acf3a9ae5a026ec1d44518bd",
    "url": "/namaz/img/dhuhr-w.8cd323c2.jpg"
  },
  {
    "revision": "71b5a41cfc30f94eb576334075aa569a",
    "url": "/namaz/img/asr.71b5a41c.jpg"
  },
  {
    "revision": "cfbecbafcfdc2b0158e830de3bd77b55",
    "url": "/namaz/img/asr-w.cfbecbaf.jpg"
  },
  {
    "revision": "ebc11d11ea145ad1bef8f7941075c7e8",
    "url": "/namaz/img/maghrib.ebc11d11.jpg"
  },
  {
    "revision": "b56bcc0bb71227a60b155da3dcf59f78",
    "url": "/namaz/img/maghrib-w.b56bcc0b.jpg"
  },
  {
    "revision": "06ced615e89b6a2d561f35389b4564fe",
    "url": "/namaz/img/isha.06ced615.jpg"
  },
  {
    "revision": "5c92abd87dc5a0f3e328e2e6ea3c9594",
    "url": "/namaz/img/isha-w.5c92abd8.jpg"
  },
  {
    "revision": "2efd5c64c5b3904e243d519e7123c66d",
    "url": "/namaz/img/witr.2efd5c64.jpg"
  },
  {
    "revision": "f97f7090d0869e5d28aacd5e65a2d051",
    "url": "/namaz/img/witr-w.f97f7090.jpg"
  },
  {
    "revision": "94ad9ba9cdf8bdb0898a991cf8cfe447",
    "url": "/namaz/img/jumuah.94ad9ba9.png"
  },
  {
    "revision": "7b3fb7477e2e39fa068df3bb4be87cdd",
    "url": "/namaz/img/istibra.7b3fb747.png"
  },
  {
    "revision": "d9afb6d3f4e68aaf8ace",
    "url": "/namaz/css/shart.c57d9707.css"
  },
  {
    "revision": "be67d3570daa0595844e",
    "url": "/namaz/css/namaz~tahharah~wudu.e3b87c3c.css"
  },
  {
    "revision": "0542b66751fb4309cf51",
    "url": "/namaz/css/namaz~solaatil-uulaa~wudu.df0c481e.css"
  },
  {
    "revision": "1391764beb6b241f74a6",
    "url": "/namaz/css/namaz.9b8b4c77.css"
  },
  {
    "revision": "68e18937bc0845ead9ea",
    "url": "/namaz/css/app.9d7541b2.css"
  }
];